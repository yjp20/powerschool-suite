# powerschool-suite

Simple powerschool extension for Seoul International School students that adds script tags to respective pages to load custom javascript that makes people's lives easier. To 'build' just zip this package and add it as an extension, or alternative snatch it from [Google Chrome Store](TBD) or [Firefox extensions](TBD).

The actual logic of the code (which you probably want) is stored within [powerschool-suite-server](https://github.com/youngjinpark20/powerschool-suite-server).
