script = document.createElement('script');
script.src = 'https://youngjin.io/ps/home.js';

document.body.appendChild(script);

