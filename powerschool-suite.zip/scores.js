script = document.createElement('script');
script.src = 'https://youngjin.io/ps/scores.js';

document.body.appendChild(script);

